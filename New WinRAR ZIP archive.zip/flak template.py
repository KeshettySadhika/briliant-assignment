[10:09 AM, 9/29/2024] Sadhiii💗: from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(_name_)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    bio = db.Column(db.Text, nullable=True)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/form', methods=['GET', 'POST'])
def form():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'], method='sha256')
        age = request.form['age']
        bio = request.form['bio']
        if not username or not password or not age:
            flash('All fields are required!')
            return redirect(url_for('form'))
        new_user = User(username=username, password=password, age=age, bio=bio)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('display'))
    return render_template('form.html')

@app.route('/display')
def display():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    users = User.query.all()
    return render_template('display.html', users=users)

@app.route('/api/users', methods=['GET'])
def api_users():
    users = User.query.all()
    user_list = [{'username': user.username, 'age': user.age, 'bio': user.bio} for user in users]
    return jsonify(user_list)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect(url_for('form'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'], method='sha256')
        age = request.form['age']
        bio = request.form['bio']
        if not username or not password or not age:
            flash('All fields are required!')
            return redirect(url_for('register'))
        new_user = User(username=username, password=password, age=age, bio=bio)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    user = User.query.get_or_404(id)
    if request.method == 'POST':
        user.username = request.form['username']
        user.age = request.form['age']
        user.bio = request.form['bio']
        db.session.commit()
        return redirect(url_for('display'))
    return render_template('edit.html', user=user)

@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    user = User.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('display'))

if _name_ == '_main_':
    db.create_all()
    app.run(debug=True)
[10:09 AM, 9/29/2024] Sadhiii💗: flask template