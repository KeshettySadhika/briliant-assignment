import csv

def read_csv(file_path):
    students = []
    with open(file_path, mode='r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            students.append({
                'name': row['name'],
                'age': int(row['age']),
                'grade': float(row['grade'])
            })
    return students

def calculate_average_grade(students):
    total_grade = sum(student['grade'] for student in students)
    return total_grade / len(students)

def find_top_student(students):
    top_student = max(students, key=lambda student: student['grade'])
    return top_student

# Example usage
file_path = 'students.csv'
students = read_csv(file_path)
average_grade = calculate_average_grade(students)
top_student = find_top_student(students)

print(f"Average Grade: {average_grade:.2f}")
print(f"Top Student: {top_student['name']} with grade {top_student['grade']}")

