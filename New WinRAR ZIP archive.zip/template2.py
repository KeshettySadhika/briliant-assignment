<!DOCTYPE html>
<html>
<head>
    <title>Display</title>
</head>
<body>
    <h1>Submitted Information</h1>
    <ul>
        {% for user in users %}
            <li>{{ user.username }} ({{ user.age }}): {{ user.bio }} <a href="/edit/{{ user.id }}">Edit</a> <form action="/delete/{{ user.id }}" method="POST" style="display:inline;"><button type="submit">Delete</button></form></li>
        {% endfor %}
    </ul>
</body>
</html>