<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
</head>
<body>
    <h1>Edit User Information</h1>
    <form method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="{{ user.username }}" required><br>
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" value="{{ user.age }}" required><br>
        <label for="bio">Bio:</label>
        <textarea id="bio" name="bio">{{ user.bio }}</textarea><br>
        <button type="submit">Save</button>
    </form>
</body>
</html>